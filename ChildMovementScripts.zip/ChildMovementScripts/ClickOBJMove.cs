﻿// ClickToMove.cs
//This script is run by the NPC animated NavMeshAgent and navigates to wherever the target object has been placed
//It also DESTROYS the calling object on collision with the Player
using UnityEngine;
[RequireComponent (typeof (UnityEngine.AI.NavMeshAgent))]
public class ClickOBJMove : MonoBehaviour {
	//RaycastHit hitInfo = new RaycastHit();
	UnityEngine.AI.NavMeshAgent agent;
    public float FieldOfViewAngle = 110f;
    public Transform OBJ;
    public Transform playerOBJ;
    private bool playerInSight;
    public Transform CurrentGoal;
    public GameObject GameManager;
    void Start () {
		agent = GetComponent<UnityEngine.AI.NavMeshAgent> ();
        CurrentGoal = OBJ;
	}
    void OnTriggerStay(Collider Col)
    {
        //If player hits NPC, then destroy NPC
        Debug.Log("Collision: " + gameObject.name);
        if (Col.CompareTag("Player"))  //This script is run by NPC so check PLAYER collision 
        {
            playerInSight = false;

            Vector3 direction = playerOBJ.transform.position - transform.position;
            float angle = Vector3.Angle(direction, transform.forward);

            //if (angle < FieldOfViewAngle * 0.5f)
            //{
                //Destroy(gameObject);
                CurrentGoal = playerOBJ;
            
           // }
        }
    }

    void OnTriggerEnter(Collider Col)
    {
        //If player hits NPC, then destroy NPC
        Debug.Log("Collision: " + gameObject.name);
        if (Col.CompareTag("Player"))  //This script is run by NPC so check PLAYER collision 
        {
            playerInSight = false;

            Vector3 direction = playerOBJ.transform.position - transform.position;
            float angle = Vector3.Angle(direction, transform.forward);

            if (angle < FieldOfViewAngle * 0.5f)
            {
                RaycastHit hit;

                if (Physics.Raycast(transform.position + transform.up, direction.normalized, out hit, 100f))
                {
                    //Destroy(gameObject);
                    CurrentGoal = playerOBJ;
                }
            }
            /*if (Col.CompareTag("Player"))
            {
                GameManager.GetComponent<gameManager>().DealDamage(6);
            }*/
        }
    }

    void OnTriggerExit(Collider Col)
    {
        CurrentGoal = OBJ;
    }
        void Update () 
	{

        agent.destination = CurrentGoal.position;
    }
}
