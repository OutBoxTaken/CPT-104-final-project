﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ChildBehavior : MonoBehaviour
{
    public Transform childGoal;
    public AudioClip audioClip;
    public AudioSource audioSource;
    
    
    //public Transform buildingBlocks;

    void Start()
    {
        transform.position = new Vector3(15,14,-12);
    }
    /*void Update()
    {
        if (audioSource.isPlaying)
        {
            NavMeshAgent agent = GetComponent<NavMeshAgent>();
            agent.destination = childGoal.position;
        }
    }*/
    
}