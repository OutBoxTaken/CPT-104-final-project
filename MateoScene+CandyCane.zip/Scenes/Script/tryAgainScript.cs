﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class tryAgainScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = true;
        Screen.lockCursor = false;
    }

    public void onTryAgain()
    {
        Debug.Log("Try Again Button Pressed");
        Score.CurrentScore = 0;
        //Any other values that need to be reset
        //SceneManager.LoadScene("Starting Area/Menu")
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
