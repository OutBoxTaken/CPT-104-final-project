﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Script needs to be started once at the beginning of the game.

public class Score : MonoBehaviour
{
    public static int CurrentScore;
    public static int BestScore;

    //Variables for house socres?

    // Start is called before the first frame update
    void Start()
    {
        BestScore = 0;
        CurrentScore = 10;
    }

    // Update is called once per frame
    void Update()
    {
        //Update house scores?
        //Score = House 1 Score + House 2 Score + ...... / Number of Houses
    }
}
