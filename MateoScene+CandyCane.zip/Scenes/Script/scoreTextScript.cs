﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class scoreTextScript : MonoBehaviour
{
    public Text ScoreBoard;
    // Start is called before the first frame update
    void Start()
    {
        ScoreBoard = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if (SceneManager.GetActiveScene().name == "WinScreen")
        {
            if (Score.CurrentScore > Score.BestScore)
            {
                Score.BestScore = Score.CurrentScore;
            }
            ScoreBoard.text = ("Best Christmas Ever!\nYour Score: " + Score.CurrentScore + "%\nBest Score: " + Score.BestScore + "%");
        }
        else
        {
            ScoreBoard.text = ("Santa Never Came!\nCurrent Score: " + Score.CurrentScore + "%\nBest Score: " + Score.BestScore + "%");
        }
    }
}
