﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CandyCane : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void OnTriggerEnter(Collider Col)
    {
        if (Col.CompareTag("Player"))
        {
            Destroy(gameObject);
        }
    }
    void OnDestroy()
    {
        //Get Candy Cane Crowbar;
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
