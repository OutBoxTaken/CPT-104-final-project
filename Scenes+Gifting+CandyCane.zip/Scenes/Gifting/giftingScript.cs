﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class giftingScript : MonoBehaviour
{
    // Start is called before the first frame update
    public bool gifted;
    void Start()
    {
        gifted = false;
    }

    void OnTriggerEnter(Collider Col)
    {
        if (Col.CompareTag("Player"))
        {
            if (gifted == false)
            {
                gifted = true;

                if (gameObject.tag == "CTree")
                {
                    //Increase score alot
                }
                if (gameObject.tag == "Stocking")
                {
                    //Increase score a little bit

                }

                Debug.Log("Gifting activated");
                foreach (Renderer r in GetComponentsInChildren<MeshRenderer>())
                    r.enabled = true;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
