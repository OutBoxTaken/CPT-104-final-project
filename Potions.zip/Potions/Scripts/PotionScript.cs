﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PotionScript : MonoBehaviour
{
    // Start is called before the first frame update
    public Animator anim;
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    void OnTriggerEnter(Collider Col)
    {
        //gameManager.itemPickUp(1);
        if (Col.CompareTag("Player"))
        {
            anim.SetBool("getpotion", true);

            Invoke("potionGet", 0.8f);
        }
            
    }
    
    void potionGet()
    {
        if (gameObject.tag == "HealthP")
        {
            //gameManager.itemPickUp(1);
            Debug.Log("Health Potion Pickup");
        }
        else if (gameObject.tag == "MagicP")
        {
            //gameManager.itemPickUp(2);
            Debug.Log("Magic Potion Pickup");
        }
        else if (gameObject.tag == "GravityP")
        {
            //gameManager.itemPickUp(3);
            Debug.Log("Gravity Potion Pickup");
        }
        else if (gameObject.tag == "SpeedP")
        {
            //gameManager.itemPickUp(4);
            Debug.Log("Speed Potion Pickup");
        }
        else
        {
            Debug.Log("picked up unknown");
        }
        Destroy(gameObject);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
