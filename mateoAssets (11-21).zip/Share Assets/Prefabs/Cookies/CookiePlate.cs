﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CookiePlate : MonoBehaviour
{
    public GameObject cookies;
    public static bool cookiesEaten;
    public AudioSource cookiesGetSound;
    // Start is called before the first frame update
    void Start()
    {
        cookiesGetSound = GetComponent<AudioSource>();
        cookiesEaten = false;
    }
    void OnTriggerEnter(Collider Col)
    {
        if (Col.CompareTag("Player"))
        {
            if (cookiesEaten == false)
            {
                cookiesEaten = true;
                Destroy(cookies);
                cookiesGetSound.Play();

                //insert script to increase cookie count
            }
        }
    }
    
    void Update()
    {
        
    }
}
