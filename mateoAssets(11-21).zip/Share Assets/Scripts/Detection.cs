﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Detection : MonoBehaviour
{
    // Start is called before the first frame update
    public static int AlertStatus;
    public static float AlertTime;
    // 0 = hidden, 1 = noise, 2 = alert, 3 = evasion
    void Start()
    {
        AlertStatus = 0;
        AlertTime = 0.0f;
        //when 0, patrols engage normal behavior unaware of santas presense
    }

    // Update is called once per frame
    void Update()
    {
        if (AlertStatus == 1)
            //Patrol behavior for investigating house, after investigation return to original position and Mode set to hidden. 
            //Set when santa makes noise in house.
        if (AlertStatus == 2)
            //Behavior for being alert. Set when santa is directly seen.
            AlertTime = 10.0f;
        if (AlertStatus == 3)
            //Behavior for when hidden during alert
            AlertTime -= Time.deltaTime;
        
        //if child sees cookies missing during noise mode, AlertStatus goes straight to hidden.
        //when AlertTime goes to 0, mode goes from 3 straight to 0
    }       
}
