﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mateoPlayerScript : MonoBehaviour
{
    // Start is called before the first frame update
    public static int Health;
    public static int Magic;
    public static int Cookies;
    void Start()
    {
        Health = 100;
        Magic = 100;
    }

    // Update is called once per frame
    void Update()
    {
    }
}
